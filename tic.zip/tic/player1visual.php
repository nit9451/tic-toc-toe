<html>
<head>
<meta http-equiv="refresh" content="12">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.7/css/mdb.min.css" rel="stylesheet">
</head>
<body>
    <div class="row">
        <div class="col-md-6 col-lg-6">
        <IFRAME NAME="name" width="100%" height="100%" SRC="common.php"></IFRAME>
        </div>
        <div class="col-md-6 col-lg-6">
            <div class="row">
                <div class="col-md-12 col-lg-12">
                <IFRAME NAME="name" width="100%" height="300px"  SRC="player1button.php"></IFRAME>
                <div>
            <div>
            <div class="row">
                <div class="col-md-12 col-lg-12">
                <IFRAME NAME="name" width="100%" height="500px"  SRC="player1.php" frameborder="1"></IFRAME>
                <div>
            <div>    
        </div>    
    </div>
    <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.7/js/mdb.min.js"></script>
</body>
</html>