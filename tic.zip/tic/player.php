<div>
<IFRAME NAME="name" width="50%" height="100%" SRC="common.php"></IFRAME>
<IFRAME NAME="Spotguide" width="49%" height="100%" SRC="player1.php"></IFRAME>
</div>
