<?php
$fname = $_POST['field_name'];
//$value = $_POST['pass'];
print ($fname);
//print ($value);
$dbname = "datastore";
// Create connection
$conn = mysqli_connect("localhost","root", '', $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//goes here
$result =mysqli_query($conn,"select * from field where $fname='-'");
// $row = mysqli_fetch_array($result);
$count = mysqli_num_rows($result);
 if($count == 1)
 {
   //session_start();
   //$_SESSION["name"] = $name;
  // echo 'Hi, ' . $_SESSION["name"] . ' ';
   $sql = "UPDATE field SET $fname='x',status=status+1";
   if (mysqli_query($conn, $sql)) 
    {
   // echo "New record created successfully";
   //header('Location:/tic/index.html'); 	
    } else 
    {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
   echo "Successfully Entered value";
}
  else
  {
    echo "Cannot insert here";
  }
?>