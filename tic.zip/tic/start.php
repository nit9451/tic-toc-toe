<div>
<IFRAME NAME="name" width="50%" height="100%" SRC="common.php"></IFRAME>

</div>

