<html>
<head>
<meta http-equiv="refresh" content="5">
<style>
table {
text-align:center;
font-family: Arial, Helvetica, sans-serif;
font-size:45px;
border: 1px solid #DDD;
margin-top:150px;
margin-left:320px;
}
h1,h2
{
    text-align:center;
    margin-top:30px;
}
</style>
</head>
<body>
    <h1>Game on progress!!</h1>
    <h2>TIC TAC TOE</h2>
<?php
  $xmessage = "Game Over!!player 1 wins the game";
  $omessage = "Game Over!!player 2 wins the game";
  $nomessage = "Game Over!!Game ended up in a draw";
$dbname = "datastore";
// Connect to the database
$conn = mysqli_connect("localhost","root", '', $dbname);
// Make sure we connected successfully
if(! $conn)
{
    die('Connection Failed'.mysql_error());
}
//
$query = "SELECT * FROM field";
if ($result = $conn->query($query)) {
 
    /* fetch associative array */
    while ($row = $result->fetch_assoc()) {
        $field00name = $row['c00'];
        $field01name = $row['c01'];
        $field02name = $row['c02'];
        $field10name = $row['c10'];
        $field11name = $row['c11'];
        $field12name = $row['c12'];
        $field20name = $row['c20'];
        $field21name = $row['c21'];
        $field22name = $row['c22'];
        
            if($field00name=='x' && $field01name=='x' && $field02name=='x')
            echo "<script type='text/javascript'>alert('$xmessage');</script>";
            else if($field10name=='x' && $field11name=='x' && $field12name=='x')
                echo "<script type='text/javascript'>alert('$xmessage');</script>";
            else if($field20name=='x' && $field21name=='x' && $field22name=='x')
                echo "<script type='text/javascript'>alert('$xmessage');</script>";
            else if($field00name=='x' && $field10name=='x' && $field20name=='x')
                echo "<script type='text/javascript'>alert('$xmessage');</script>";
            else if($field01name=='x' && $field11name=='x' && $field21name=='x')
                echo "<script type='text/javascript'>alert('$xmessage');</script>";
            else if($field02name=='x' && $field12name=='x' && $field22name=='x')
                echo "<script type='text/javascript'>alert('$xmessage');</script>";
            else if($field00name=='x' && $field11name=='x' && $field22name=='x')
                echo "<script type='text/javascript'>alert('$xmessage');</script>";
            else if($field02name=='x' && $field11name=='x' && $field20name=='x')
                echo "<script type='text/javascript'>alert('$xmessage');</script>";
            //condition for o
            else if($field00name=='o' && $field01name=='o' && $field02name=='o')
                echo "<script type='text/javascript'>alert('$omessage');</script>";
            else if($field10name=='o' && $field11name=='o' && $field12name=='o')
                echo "<script type='text/javascript'>alert('oxmessage');</script>";
            else if($field20name=='o' && $field21name=='o' && $field22name=='o')
                echo "<script type='text/javascript'>alert('$omessage');</script>";
            else if($field00name=='o' && $field10name=='o' && $field20name=='o')
                echo "<script type='text/javascript'>alert('$omessage');</script>";
            else if($field01name=='o' && $field11name=='o' && $field21name=='o')
                echo "<script type='text/javascript'>alert('$omessage');</script>";
            else if($field02name=='o' && $field12name=='o' && $field22name=='o')
                echo "<script type='text/javascript'>alert('$omessage');</script>";
            else if($field00name=='o' && $field11name=='o' && $field22name=='o')
                echo "<script type='text/javascript'>alert('$omessage');</script>";
            else if($field02name=='o' && $field11name=='o' && $field20name=='o')
                echo "<script type='text/javascript'>alert('$omessage');</script>";
            else if($field00name!='-' && $field01name!='-' && $field02name!='-' && $field10name!='-' && $field11name!='-' && $field12name!='-' 
        && $field20name!='-' && $field21name!='-' && $field22name!='-')
                echo "<script type='text/javascript'>alert('$nomessage');</script>";
               //header('Location:/tic/index.html');
            
       
        echo '<table><tr> 
        <td>'.$field00name.'</td> 
        <td>'.$field01name.'</td> 
        <td>'.$field02name.'</td> 
        </tr><br>';
        echo '<tr> 
        <td>'.$field10name.'</td> 
        <td>'.$field11name.'</td> 
        <td>'.$field12name.'</td> 
        </tr><br>';
        echo '<tr> 
        <td>'.$field20name.'</td> 
        <td>'.$field21name.'</td> 
        <td>'.$field22name.'</td> 
        </tr><table>';
    }
 
    /* free result set */
    $result->free();
}
$conn->close();
?>

</body>
<html>

