<html>
  <head>
    <style>
    h2
   {
     text-align:center;
     margin-bottom:100px;
     color:green;
   }
   h1
   {
     text-align:center;
     margin-bottom:100px;
     color:red;
   }
     </style>
</head>
<body>
<?php
$dbname = "datastore";
// Connect to the database
$conn = mysqli_connect("localhost","root", '', $dbname);
// Make sure we connected successfully
if(! $conn)
{
    die('Connection Failed'.mysql_error());
}
$result =mysqli_query($conn,"select * from field where status % 2 = 0");
// $row = mysqli_fetch_array($result);
$count = mysqli_num_rows($result);
 if($count == 1)
 {
   //session_start();
  // $_SESSION["name"] = $name;
  // echo 'Hi, ' . $_SESSION["name"] . ' ';
  echo "<h2>You can make your Move</h2>";
  //  header('Location: /templatemo_527_sided/welcome.php\'); 
   //echo 'Hi, ' . $_SESSION["name"] . ' ';
  }
  else
  {
    echo "<h1>Player1 has not Completed.Please Wait!!!<h1>";
  }
  //sleep(15);
  //header('Location:/tic/player1check.php');
?>
</body>
</html>

